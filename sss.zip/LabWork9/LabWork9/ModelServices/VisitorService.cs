﻿using LabWork9.Context;
using LabWork9.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork9.ModelServices
{
    public class VisitorService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Visitor>> GetVisitorsAsync()
        {
            return await _context.Visitors.ToListAsync();
        }

        public async Task AddVisitorsAsync(Visitor visitor)
        {
            _context.Visitors.Add(visitor);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateVisitorsAsync(Visitor visitor)
        {
            throw new NotImplementedException();
        }

        public async Task DeleteVisitorAsync(int id)
        {
            var visitor = _context.Visitors.Find(id);
            if (visitor != null)
            {
                _context.Visitors.Remove(visitor);
                await _context.SaveChangesAsync();
            }
        }
    }
}
