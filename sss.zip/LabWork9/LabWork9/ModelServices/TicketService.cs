﻿using LabWork9.Context;
using LabWork9.Models;
using Microsoft.EntityFrameworkCore;

namespace LabWork9.ModelServices
{
    public class TicketService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Ticket>> GetTicketsAsync()
        {
            return await _context.Tickets.ToListAsync();
        }

        public async Task AddTicketsAsync(Ticket ticket)
        {
            _context.Tickets.Add(ticket);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateTicketsAsync(Ticket ticket)
        {
            throw new NotImplementedException();
        }

        public async Task DeleteTicketAsync(int id)
        {
            var ticket = _context.Tickets.Find(id);
            if (ticket != null)
            {
                _context.Tickets.Remove(ticket);
                await _context.SaveChangesAsync();
            }
        }
    }
}
