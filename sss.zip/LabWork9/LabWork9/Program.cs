﻿using LabWork9.Context;
using LabWork9.Models;
using LabWork9.ModelServices;

using var context = new AppDbContext();

var visitorService = new VisitorService(context);
var ticketService = new TicketService(context);

// задание 2: получение кол-ва посетителей и билетов
var visitors = await visitorService.GetVisitorsAsync();
Console.WriteLine($"посетителей: {visitors.Count}");

var tickets = await ticketService.GetTicketsAsync();
Console.WriteLine($"билетов: {tickets.Count}");

// задание 3: обновление посетителей и билетов

var visitor = new Visitor
{
    Phone = "8846344312",
    Name = "Пьотр Каграманян",
    Birthday = new DateTime(2001, 9, 11),
    Email = "yaloh@gmail.ru"
};

await visitorService.AddVisitorsAsync(visitor);

var ticket = new Ticket
{
    VisitorId = visitor.VisitorId,
    SessionId = 6,
    Row = 5,
    Seat = 13
};

await ticketService.AddTicketsAsync(ticket);

Console.WriteLine($"отныне посетителей: {visitors.Count}");
Console.WriteLine($"отныне билетов: {tickets.Count}");

// задание 5: удаление посетителей и билетов

await visitorService.DeleteVisitorAsync(2);
await ticketService.DeleteTicketAsync(6);
