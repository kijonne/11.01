﻿using LabWork9.Models;
using Microsoft.EntityFrameworkCore;

namespace LabWork9.Context
{
    public class AppDbContext : DbContext
    {
        public DbSet<Visitor> Visitors => Set<Visitor>();
        public DbSet<Ticket> Tickets => Set<Ticket>();

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public AppDbContext()
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=mssql;User ID=ispp3410;Password=3410;Trust Server Certificate=True");
        }
    }

}
