﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork8.Repository
{
    public class UserRepository(DatabaseContext dbContext)
    {
        private readonly DatabaseContext _dbContext = dbContext;

    }
}
