﻿using System;


    class Program
    {
        static void Main(string[] args)
        {
            double a = 2.0;
            double b = 3.0;
            int n = 10;

            double result = GaussianQuadrature(f, a, b, n);
            Console.WriteLine(result.ToString("F8"));
            Console.ReadLine();
        }

        static double f(double x)
        {
            return x * x * Math.Cos(x / 4.0);
        }

        static double GaussianQuadrature(Func<double, double> func, double a, double b, int n)
        {
            double h = (b - a) / n;
            double sum = 0.0;
            double sqrt3 = 1.0 / Math.Sqrt(3.0);

            for (int i = 0; i < n; i++)
            {
                double xi = a + i * h;
                double x1 = xi + h / 2 - (h / 2) * sqrt3;
                double x2 = xi + h / 2 + (h / 2) * sqrt3;

                sum += func(x1) + func(x2);
            }

            return (h / 2) * sum;
        }
    }
