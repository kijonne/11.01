﻿using System;

class GaussianElimination
{
    static void Main()
    {
        // матрица коэффициентов
        double[,] A = new double[,] {
            {63, 5, -25},
            {16, -10, 71},
            {3, -34, 10}
        };

        double[] B = new double[] { -34, 31, 32 };

        double[] solution = SolveGaussian(A, B);

        Console.WriteLine("Решение системы:");
        Console.WriteLine("x1 = " + solution[0].ToString("F2"));
        Console.WriteLine("x2 = " + solution[1].ToString("F2"));
        Console.WriteLine("x3 = " + solution[2].ToString("F2"));
        Console.ReadKey();
    }

    // метод гаусса для решения
    static double[] SolveGaussian(double[,] A, double[] B)
    {
        int n = B.Length;
        double[,] AB = new double[n, n + 1];

        // создаем расширенную матрицу
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                AB[i, j] = A[i, j];
            }
            AB[i, n] = B[i];
        }

        // прямой ход
        for (int i = 0; i < n; i++)
        {
            // ищем главный элемент по столбцу
            int maxRow = i;
            for (int k = i + 1; k < n; k++)
            {
                if (Math.Abs(AB[k, i]) > Math.Abs(AB[maxRow, i]))
                    maxRow = k;
            }

            // перестановка строк
            if (maxRow != i)
            {
                for (int k = 0; k <= n; k++)
                {
                    double temp = AB[i, k];
                    AB[i, k] = AB[maxRow, k];
                    AB[maxRow, k] = temp;
                }
            }

            // приведение к треугольному виду
            for (int k = i + 1; k < n; k++)
            {
                double factor = AB[k, i] / AB[i, i];
                for (int j = i; j <= n; j++)
                {
                    AB[k, j] = AB[k, j] - factor * AB[i, j];
                }
            }
        }

        // обратный ход
        double[] X = new double[n];
        for (int i = n - 1; i >= 0; i--)
        {
            X[i] = AB[i, n];
            for (int j = i + 1; j < n; j++)
            {
                X[i] = X[i] - AB[i, j] * X[j];
            }
            X[i] = X[i] / AB[i, i];
        }

        return X;
    }
}