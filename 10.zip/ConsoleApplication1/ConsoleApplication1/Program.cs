﻿using System;

namespace EulerMethod
{
    class Program
    {
        static double f(double x, double y)
        {
            return (3 * y / x) + x;
        }

        static void Main(string[] args)
        {
            double x;
            double y;
            double h;
            double b;
            Console.WriteLine("введите начальное х: ");
            x = double.Parse(Console.ReadLine());

            Console.WriteLine("введите начальное у:");
            y = double.Parse(Console.ReadLine());

            Console.WriteLine("введите шаг h: ");
            h = double.Parse(Console.ReadLine());

            Console.WriteLine("введите конечное b: ");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("\n Результаты: ");
            Console.WriteLine("{0,-10}-{1,-10}", "x", "y");

            while (x <= b + h / 2)
            {
                Console.WriteLine("{0,-10:F1}{1-10:F3}", x, y);
                y = y + h * f(x, y);
                x = x + h;
            }
            Console.ReadKey();
        }
    }
}