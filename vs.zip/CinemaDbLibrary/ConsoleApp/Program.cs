﻿using CinemaDbLibrary;
using CinemaDbLibrary.Context;
using CinemaDbLibrary.Services;
using Microsoft.EntityFrameworkCore;
using System;


using var context = new AppDbContext();

var visitorService = new VisitorService(context);
var filmService = new FilmService(context);
var ticketService = new TicketService(context);
var genreService = new GenreService(context);

Console.WriteLine("все посетители");
var visitors = await visitorService.GetAllAsync();
foreach (var visitor in visitors)
{
    Console.WriteLine($"{visitor.VisitorId}: {visitor.Name}");
}
Console.WriteLine();

Console.WriteLine("все фильмы");
var films = await filmService.GetAllAsync();
foreach (var film in films)
{
    Console.WriteLine($"{film.FilmId}: {film.Title}");
}
Console.WriteLine();

Console.WriteLine("все билеты");
var tickets = await ticketService.GetAllAsync();
foreach (var ticket in tickets)
{
    Console.WriteLine($"{ticket.TicketId}");
}
Console.WriteLine();

Console.WriteLine("все жанры");
var genres = await genreService.GetAllAsync();
foreach (var genre in genres)
{
    Console.WriteLine($"{genre.GenreId}: {genre.Title}");
}
Console.WriteLine();