﻿using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Context
{
    public class AppDbContext : DbContext
    {
        public DbSet<Visitor> Visitors => Set<Visitor>();
        public DbSet<Ticket> Tickets => Set<Ticket>();
        public DbSet<Film> Films => Set<Film>();
        public DbSet<Genre> Genres => Set<Genre>();

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public AppDbContext()
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer("Data Source=mssql;Initial Catalog=ispp3110;User ID=ispp3110;Password=3110;Trust Server Certificate=True");
        }
    }
}
