﻿using CinemaDbLibrary.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Services
{
    public class GenreService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<Genre?> GetByIdAsync(int id)
        {
            return await _context.Genres.FindAsync(id);
        }

        public async Task<List<Genre>> GetAllAsync()
        {
            return await _context.Genres.ToListAsync();
        }
    }
}
