﻿using CinemaDbLibrary.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Services
{
    public class VisitorService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<Visitor?> GetByIdAsync(int id)
        {
            return await _context.Visitors.FindAsync(id);
        }

        public async Task<List<Visitor>> GetAllAsync()
        {
            return await _context.Visitors.ToListAsync();
        }
    }
}
