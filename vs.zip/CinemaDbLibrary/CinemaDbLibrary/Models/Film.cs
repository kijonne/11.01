﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Models
{
    [Table("Film")]
    public class Film
    {
        public int FilmId { get; set; }
        public string Title { get; set; } = null!;
        public short Duration { get; set; }
        public short Year { get; set; }
        public string? Description { get; set; }
        public byte[]? Poster { get; set; }
        public string? AgeRating { get; set; }
        public DateTime? StartDistribution { get; set; }

        public IEnumerable<Genre>? Genres { get; set; }
        public IEnumerable<Ticket>? Tickets { get; set; }
    }
}
