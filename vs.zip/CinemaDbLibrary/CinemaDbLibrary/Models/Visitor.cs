﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Models
{
    [Table("Visitor")]
    public class Visitor
    {
        public int VisitorId { get; set; }
        public string Phone { get; set; } = null!;
        public string? Name { get; set; }
        public DateTime? Birthday { get; set; }
        public string? Email { get; set; }

        public IEnumerable<Ticket>? Tickets { get; set; }
    }
}