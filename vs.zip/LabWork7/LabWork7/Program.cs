﻿using LabWork7;
/*1.1*/
Console.WriteLine($"Строка подключения: {DataAccessLayer.ConnectionString}");

Console.WriteLine();

/*1.2*/
DataAccessLayer.ChangeConnectionSettings("new_mssql", "new", "new_ispp3110", "new_3110");
Console.WriteLine($"Новая строка подключения: {DataAccessLayer.ConnectionString}");

Console.WriteLine();

/*1.3*/
DataAccessLayer.ChangeConnectionSettings("mssql", "", "ispp3110", "3110");
Console.WriteLine($"Cтрока подключения: {DataAccessLayer.ConnectionString}");
bool isConnected = DataAccessLayer.TestConnection();
Console.WriteLine($"Подключение к БД: {(isConnected ? "Подключено" : "Не Подключено")}");

Console.WriteLine();

/*2.1*/
string createTableSql = @"
            CREATE TABLE Test (
            [title_id] [varchar](6) NOT NULL,
            [title] [varchar](80) NOT NULL,
            ";
int result = await DataAccessLayer.ExecuteNonQueryAsync(createTableSql);
Console.WriteLine($"Таблица создана. Затронуто строк: {result}\n");

/*2.2*/
object scalarResult = await DataAccessLayer.ExecuteScalarAsync("SELECT COUNT(*) FROM Test");
Console.WriteLine($"Количество записей в TestTable: {scalarResult}\n");