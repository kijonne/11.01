﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork7
{
    public static class DataAccessLayer
    {
        //1
        private static string _server = "mssql";
        private static string _database = "";
        private static string _login = "ispp3110";
        private static string _password = "3110";

        public static string ConnectionString 
        { 
            get 
            {
                var builder = new SqlConnectionStringBuilder
                {
                    DataSource = _server,
                    InitialCatalog = _database,
                    UserID = _login,
                    Password = _password,
                    TrustServerCertificate = true
                };
                return builder.ConnectionString;
            }
        } 

        public static void ChangeConnectionSettings(string server, string database, string login, string password)
        {
            _server = server;
            _database = database;
            _login = login;
            _password = password;
        }

        public static bool TestConnection()
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    connection.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        //2
        public static async Task<int> ExecuteNonQueryAsync(string sqlCommand)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand(sqlCommand, connection))
                {
                    await connection.OpenAsync();
                    return await command.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка выполнения команды: {ex.Message}");
                return -1;
            }
        }

        public static async Task<object?> ExecuteScalarAsync(string sqlCommand)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand(sqlCommand, connection))
                {
                    await connection.OpenAsync();
                    return await command.ExecuteScalarAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка выполнения команды: {ex.Message}");
                return null;
            }
        }
    }
}
