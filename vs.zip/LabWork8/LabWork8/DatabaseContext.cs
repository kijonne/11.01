﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork8
{
    public class DatabaseContext
    {
        private readonly string _connectionString;

        public DatabaseContext(string server, string database, string login, string password)
        {
            _connectionString = $"Server={server}; Database={database}; UserId={login}; Password={password};";
        }

        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
    }
}
