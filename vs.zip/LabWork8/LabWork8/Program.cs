﻿using LabWork8;
using LabWork8.Repository;
using Microsoft.Data.SqlClient;

var dbContext = new DatabaseContext("mssql", "", "ispp3110", "3110");

var userRepository = new UserRepository(dbContext);
var genreRepository = new GenreRepository(dbContext);

try
{
    using var connection = dbContext.CreateConnection();
    connection.Open();
    Console.WriteLine("open");
}
catch
{
    Console.WriteLine("don't open");
}