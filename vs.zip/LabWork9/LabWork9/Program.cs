﻿using LabWork9.Context;
using LabWork9.Models;
using LabWork9.ModelServices;

using var context = new AppDbContext();

var visitorService = new VisitorService(context);
var ticketService = new TicketService(context);

//2
var visitors = await visitorService.GetVisitorsAsync();
Console.WriteLine($"Посетителей: {visitors.Count}");

var tickets = await ticketService.GetTicketsAsync();
Console.WriteLine($"Билетов: {tickets.Count}");

//3
var visitor = new Visitor
{
    Phone = "121551",
    Name = "олег марканьян",
    Birthday = new DateTime(2002, 1, 11),
    Email = "markanyan@gmail.ru"
};

await visitorService.AddVisitorsAsync(visitor);

var ticket = new Ticket
{
    VisitorId = visitor.VisitorId,
    SessionId = 7,
    Row = 5,
    Seat = 11
};

await ticketService.AddTicketsAsync(ticket);

Console.WriteLine($"отныне посетителей: {visitors.Count}");
Console.WriteLine($"отныне билетов: {tickets.Count}");