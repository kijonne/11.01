﻿using labwork8;

class Program
{
    static async Task Main(string[] args)
    {
        // 1
        var dbContext = new DatabaseContext("mssql", "", "ispp3410", "3410");

        var visitorRepository = new VisitorRepository(dbContext);
        var genreRepository = new GenreRepository(dbContext);

        // 3
        var allVisitors = await visitorRepository.GetAllAsync();
        Console.WriteLine($"всего посетителей: {allVisitors?.Count() ?? 0}");

        var newVisitor = new Visitor
        {
            Name = "оля",
            Email = "olelech7@mail.ru",
            Phone = "+79027",
            Birthday = new DateTime(2005, 12, 11)
        };

        // 4
        var newVisitorId = await visitorRepository.AddAsync(newVisitor);
        Console.WriteLine($"добавлен посетитель с айди {newVisitorId}");

        // 3
        var visitor = await visitorRepository.GetByIdAsync(newVisitorId);
        Console.WriteLine($"найден посетитель: {visitor?.Name}");

        visitor.Name = "Иван Петров";
        await visitorRepository.UpdateAsync(visitor);
        Console.WriteLine("посетитель обновлен");

        var newGenre = new Genre
        {
            Title = "аниме"
        };

        // 4 
        var newGenreId = await genreRepository.AddAsync(newGenre);
        Console.WriteLine($"добавлен жанр со следующим айди: {newGenreId}");

        // 3
        var allGenres = await genreRepository.GetAllAsync();
        Console.WriteLine($"всего жанров: {allGenres?.Count() ?? 0}");

        // 5
        await genreRepository.DeleteAsync(newGenreId);
        Console.WriteLine("жанр удалили");

        await visitorRepository.DeleteAsync(newVisitorId);
        Console.WriteLine("посетитель удален");

    }
}