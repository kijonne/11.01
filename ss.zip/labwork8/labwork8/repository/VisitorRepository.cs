﻿using Dapper;
using labwork8;

public class VisitorRepository(DatabaseContext dbContext) : IRepository<Visitor>
{
    private readonly DatabaseContext _dbContext = dbContext;

    // 3
    public async Task<Visitor> GetByIdAsync(int id)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "SELECT * FROM Visitor WHERE VisitorId = @VisitorId";
        return await connection.QuerySingleOrDefaultAsync<Visitor>(sql, new { VisitorId = id });
    }

    public async Task<IEnumerable<Visitor>> GetAllAsync()
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "SELECT * FROM Visitor";
        return await connection.QueryAsync<Visitor>(sql);
    }

    // 4
    public async Task<int> AddAsync(Visitor entity)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "INSERT INTO Visitor (Name, Email, Phone, Birthday) OUTPUT INSERTED.VisitorId VALUES (@Name, @Email, @Phone, @Birthday)";
        return await connection.ExecuteScalarAsync<int>(sql, entity);
    }

    // 5
    public async Task UpdateAsync(Visitor entity)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "UPDATE Visitor SET Name = @Name, Email = @Email, Phone = @Phone, Birthday = @Birthday WHERE VisitorId = @VisitorId";
        await connection.ExecuteAsync(sql, entity);
    }

    public async Task DeleteAsync(int id)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "DELETE FROM Visitor WHERE VisitorId = @VisitorId";
        await connection.ExecuteAsync(sql, new { VisitorId = id });
    }
}