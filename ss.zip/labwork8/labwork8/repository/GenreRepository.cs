﻿using Dapper;
using labwork8;

public class GenreRepository(DatabaseContext dbContext) : IRepository<Genre>
{
    private readonly DatabaseContext _dbContext = dbContext;

    // 3
    public async Task<Genre> GetByIdAsync(int id)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "SELECT * FROM Genre WHERE GenreId = @GenreId";
        return await connection.QuerySingleOrDefaultAsync<Genre>(sql, new { GenreId = id });
    }

    public async Task<IEnumerable<Genre>> GetAllAsync()
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "SELECT * FROM Genre";
        return await connection.QueryAsync<Genre>(sql);
    }

    // 4
    public async Task<int> AddAsync(Genre entity)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "INSERT INTO Genre (Title) OUTPUT INSERTED.GenreId VALUES (@Title)";
        return await connection.ExecuteScalarAsync<int>(sql, entity);
    }

    //5
    public async Task UpdateAsync(Genre entity)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "UPDATE Genre SET Title = @Title, WHERE GenreId = @GenreId";
        await connection.ExecuteAsync(sql, entity);
    }

    public async Task DeleteAsync(int id)
    {
        using var connection = _dbContext.CreateConnection();
        var sql = "DELETE FROM Genre WHERE GenreId = @GenreId";
        await connection.ExecuteAsync(sql, new { GenreId = id });
    }
}