﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace labwork8
{
    public class DatabaseContext
    {
        private readonly string _connectionString;

        public DatabaseContext (string server, string database, string login, string password)
        {
            _connectionString = $"Server={server};Database={database};User Id={login};Password={password};TrustServerCertificate=true;";
        }
        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
    }
}
