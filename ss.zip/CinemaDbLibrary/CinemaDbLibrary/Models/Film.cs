﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace CinemaDbLibrary.Models
{
    [Table("Film")]
    public class Film
    {
        public int FilmId { get; set; } 
        public string Title { get; set; } = null!;
        public short Duration { get; set; }
        public short PublicationYear { get; set; }
        public string? Description { get; set; }
        public byte[]? Poster {  get; set; }
        public string? AgeRating { get; set; }
        public DateTime? RentalStart { get; set; }
        public DateTime? RentalEnd { get; set; }
        public bool IsDeleted { get; set; }
    }
}
