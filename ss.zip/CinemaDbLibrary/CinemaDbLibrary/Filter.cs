﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary
{
    public class Filter
    {
        public string Title { get; set; }
        public string PartOfTitle { get; set; }
        public int? MinPublicationYear { get; set; }
        public DateTime? ShowDate { get; set; }
    }
}
