﻿using CinemaDbLibrary.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;

namespace CinemaDbLibrary.Services
{
    public class VisitorService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<Visitor?> GetByIdAsync(int id)
        {
            return await _context.Visitors.FindAsync(id);
        }

        public async Task<List<Visitor>> GetAllAsync()
        {
            return await _context.Visitors.ToListAsync();
        }

        public async Task<List<Visitor>> GetAllWithPaginationAsync(Pagination pagination)
        {
            return await _context.Visitors
                .Skip((pagination.CurrentPage - 1) * pagination.PageSize)
                .Take(pagination.PageSize)
                .ToListAsync();
        }
    }
}
