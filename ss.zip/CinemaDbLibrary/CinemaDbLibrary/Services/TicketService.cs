﻿using CinemaDbLibrary.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Services
{
    public class TicketService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;
        public async Task<Ticket?> GetByIdAsync(int id)
        {
            return await _context.Tickets.FindAsync(id);
        }

        public async Task<List<Ticket>> GetAllAsync()
        {
            return await _context.Tickets.ToListAsync();
        }
        public async Task<List<Ticket>> GetSortedTicketsAsync(Sorting sorting)
        {
            var query = _context.Tickets;

            if (sorting.Column == "TicketId")
            {
                if (sorting.IsAscending)
                    return await query.OrderBy(t => t.TicketId).ToListAsync();
                return await query.OrderByDescending(t => t.TicketId).ToListAsync();
            }

            return await query.ToListAsync();
        }
    }
}
