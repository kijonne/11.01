﻿using CinemaDbLibrary.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary.Services
{
    public class FilmService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;
        public async Task<Film?> GetByIdAsync(int id)
        {
            return await _context.Films.FindAsync(id);
        }

        public async Task<List<Film>> GetAllAsync()
        {
            return await _context.Films.ToListAsync();
        }

        public async Task<List<Film>> GetAllWithPaginationAsync(Pagination pagination)
        {
            return await _context.Films
                .Skip((pagination.CurrentPage - 1) * pagination.PageSize)
                .Take(pagination.PageSize)
                .ToListAsync();
        }

        public async Task<List<Film>> GetSortedFilmsAsync(Sorting sorting)
        {
            var query = _context.Films;

            if (sorting.Column == "Title")
            {
                if (sorting.IsAscending)
                    return await query.OrderBy(f => f.Title).ToListAsync();
                else
                    return await query.OrderByDescending(f => f.Title).ToListAsync();
            }

            if (sorting.Column == "PublicationYear")
            {
                if (sorting.IsAscending)
                    return await query.OrderBy(f => f.PublicationYear).ToListAsync();
                else
                    return await query.OrderByDescending(f => f.PublicationYear).ToListAsync();
            }

            return await query.ToListAsync();
        }

        public async Task<List<Film>> GetFilteredFilmsAsync(Filter filter)
        {
            var query = _context.Films.AsQueryable();

            if (!string.IsNullOrEmpty(filter.Title))
                query = query.Where(f => f.Title == filter.Title);

            if (!string.IsNullOrEmpty(filter.PartOfTitle))
                query = query.Where(f => f.Title.Contains(filter.PartOfTitle));

            if (filter.MinPublicationYear.HasValue)
                query = query.Where(f => f.PublicationYear >= filter.MinPublicationYear.Value);

            return await query.ToListAsync();
        }
    }
}
