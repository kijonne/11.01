﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary
{
    public class Sorting
    {
        public string Column { get; set; }
        public bool IsAscending { get; set; } = true;
    }
}
