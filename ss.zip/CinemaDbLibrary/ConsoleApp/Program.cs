﻿using CinemaDbLibrary;
using CinemaDbLibrary.Context;
using CinemaDbLibrary.Services;
using Microsoft.EntityFrameworkCore;
using System;


class Program
{
    static async Task Main(string[] args)
    {
        using var context = new AppDbContext();

        var visitorService = new VisitorService(context);
        var filmService = new FilmService(context);
        var ticketService = new TicketService(context);
        var genreService = new GenreService(context);

        Console.WriteLine("все посетители");
        var visitors = await visitorService.GetAllAsync();
        foreach (var visitor in visitors)
        {
            Console.WriteLine($"{visitor.VisitorId}: {visitor.Name}");
        }
        Console.WriteLine();

        Console.WriteLine("все фильмы");
        var films = await filmService.GetAllAsync();
        foreach (var film in films)
        {
            Console.WriteLine($"{film.FilmId}: {film.Title}");
        }
        Console.WriteLine();

        Console.WriteLine("все билеты");
        var tickets = await ticketService.GetAllAsync();
        foreach (var ticket in tickets)
        {
            Console.WriteLine($"{ticket.TicketId}");
        }
        Console.WriteLine();

        Console.WriteLine("все жанры");
        var genres = await genreService.GetAllAsync();
        foreach (var genre in genres)
        {
            Console.WriteLine($"{genre.GenreId}: {genre.Title}");
        }
        Console.WriteLine();

        Console.WriteLine("пагинация фильмов");
        var filmsPaged = await filmService.GetAllWithPaginationAsync(new Pagination());
        foreach (var film in filmsPaged)
        {
            Console.WriteLine($"{film.FilmId}: {film.Title}");
        }
        Console.WriteLine();

        Console.WriteLine("пагинация посетителев");
        var visitorsPaged = await visitorService.GetAllWithPaginationAsync(new Pagination());
        foreach (var visitor in visitorsPaged)
        {
            Console.WriteLine($"{visitor.VisitorId}: {visitor.Name}");
        }
        Console.WriteLine();

        Console.WriteLine("cортировка фильмов");
        var sortedFilms = await filmService.GetSortedFilmsAsync(new Sorting { Column = "Title", IsAscending = true });
        foreach (var film in sortedFilms)
        {
            Console.WriteLine($"{film.FilmId}: {film.Title}");
        }
        Console.WriteLine();

        Console.WriteLine("coртировка билетов");
        var sortedTickets = await ticketService.GetSortedTicketsAsync(new Sorting { Column = "Title", IsAscending = true });
        foreach (var ticket in sortedTickets)
        {
            Console.WriteLine($"{ticket.VisitorId}: {ticket.TicketId}");
        }
        Console.WriteLine();

        Console.WriteLine("фильтрация (фильмов)");
        var filteredFilms = await filmService.GetFilteredFilmsAsync(new Filter { PartOfTitle = "фильм" });
        foreach (var film in filteredFilms)
        {
            Console.WriteLine($"{film.FilmId}: {film.Title}");
        }
    }
}