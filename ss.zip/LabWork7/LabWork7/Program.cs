﻿using LabWork7;
using System.Data;

// 1
Console.WriteLine("Задание 1");
Console.WriteLine();
Console.WriteLine($"строка подключения: {DataAccessLayer.ConnectionString}");

Console.WriteLine();

DataAccessLayer.ChangeConnectionSettings("new_mssql", "new", "new_ispp3410", "new_3410");
Console.WriteLine($"новая строка подключения: {DataAccessLayer.ConnectionString}");

Console.WriteLine();

DataAccessLayer.ChangeConnectionSettings("mssql", "", "ispp3410", "3410");
Console.WriteLine($"строка подключения: {DataAccessLayer.ConnectionString}");
bool isConnected = DataAccessLayer.TestConnection();
Console.WriteLine($"подключение к БД: {(isConnected ? "подключено" : "не подключено")}");

Console.WriteLine();
Console.WriteLine("Задание 2");
Console.WriteLine();

// 2
try
{
    string createTableSql = @"
            CREATE TABLE NewTestTable (
            [test_id] [varchar](6) NOT NULL,
            [test1] [nvarchar](80) NOT NULL,
            [test2] [char](5) NOT NULL)
            ";
    int result = await DataAccessLayer.ExecuteNonQueryAsync(createTableSql);
    Console.WriteLine($"таблица создана. затронуто строк: {result}\n");
}
catch (Exception ex)
{
    Console.WriteLine($"ошибка: {ex.Message}");
}

try
{
    object scalarResult = await DataAccessLayer.ExecuteScalarAsync("SELECT COUNT(*) FROM NewTestTable");
    Console.WriteLine($"количество записей в NewTestTable: {scalarResult}\n");

}
catch (Exception ex)
{
    Console.WriteLine($"ошибка: {ex.Message}");
}


// 5
Console.WriteLine();
Console.WriteLine("Задание 5");
Console.WriteLine();

DataTable films = await DataAccessLayer.GetUpcomingFilmsAsync();
Console.WriteLine($"   Найдено фильмов: {films.Rows.Count}");

foreach (DataRow row in films.Rows)
{
    Console.WriteLine($"   - {row["Title"]} (выход: {row["PublicationYear"]})");
}

