﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace LabWork7
{
    public static class DataAccessLayer
    {
        // 1
        private static string _server = "mssql";
        private static string _database = "";
        private static string _login = "ispp3410";
        private static string _password = "3410";

        public static string ConnectionString
        {
            get
            {
                var builder = new SqlConnectionStringBuilder
                {
                    DataSource = _server,
                    InitialCatalog = _database,
                    UserID = _login,
                    Password = _password,
                    TrustServerCertificate = true
                };
                return builder.ConnectionString;
            }
        }

        public static void ChangeConnectionSettings(string server, string database, string login, string password)
        {
            _server = server;
            _database = database;
            _login = login;
            _password = password;
        }

        public static bool TestConnection()
        {
            try
            {
                using var connection = new SqlConnection(ConnectionString);
                connection.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // 2
        public static async Task<int> ExecuteNonQueryAsync(string sqlCommand)
        {
            using var connection = new SqlConnection(ConnectionString);
            using var command = new SqlCommand(sqlCommand, connection);
            await connection.OpenAsync();
            return await command.ExecuteNonQueryAsync();
        }

        public static async Task<object?> ExecuteScalarAsync(string sqlCommand)
        {
            using var connection = new SqlConnection(ConnectionString);
            using var command = new SqlCommand(sqlCommand, connection);
            await connection.OpenAsync();
            return await command.ExecuteScalarAsync();
        }

        // 5

        public static async Task<DataTable> GetUpcomingFilmsAsync()
        {
            string sql = "SELECT * FROM Film WHERE RentalStart > GETDATE()";
            var dataTable = new DataTable();

            using (var connection = new SqlConnection(ConnectionString))
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(sql, connection);
                using var reader = await command.ExecuteReaderAsync();
                dataTable.Load(reader);
            }

            return dataTable;
        }

    }
}
